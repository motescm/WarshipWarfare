This is a game created by Curtis Motes using PyProcessing. To play, be sure to download all of the files and save them into one folder. Also, be sure you have Processing and PyProcessing already installed.
Download Processing:

https://processing.org/download/

After you've downloaded processing, click Java in the top right corner, click 'Add Mode...' and install Python Mode for processing.

To play, use the WASD keys to move your tank. Press F to fire. The objective of the game is to dodge the missiles of the warship while shooting it with your own missiles. Collect the coins to boost your score. You have 3 lives, and the warship takes 15 hits to be defeated. Thank you for playing!

Warship Credits (Infernus-class Battlewagon):
https://bitbucket.org/modmafia/underworld/src/5daa214d7846fb0a49ad9d09dc3e5cdec15b4eb6/src/graphics/uw/ships/?at=master

Created by DarkRevenant

Castle Tile Credits:
http://ludumdare.com/compo/wp-content/uploads/2013/08/tile-duke-example.png

http://ludumdare.com/compo/author/adventureislands/
Taken from the Duke Dashington game

Created by Adventureislands

All other sprites were created by me using the Piskel app: htttp://www.piskelapp.com/